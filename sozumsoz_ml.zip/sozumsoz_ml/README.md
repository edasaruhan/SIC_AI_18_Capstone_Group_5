# SözümSöz – data preparation and model exploration

Code for the capstone assignment *Data Preparation / Feature Engineering and
Model Exploration*. It turns the public LSApp event log into a table of app
visits with simulated duration promises, builds leakage-safe features, and
compares a majority baseline, a history baseline, logistic regression, a
random forest and LightGBM (with probability calibration).

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python run_pipeline.py            # full run, about 10–15 minutes on one CPU core
python run_pipeline.py --skip-robustness   # EDA + main experiment only (about 3 minutes)
```

The script downloads `lsapp.tsv.gz` from the official repository
(<https://github.com/aliannejadi/LSApp>) into `data/` on first use. LSApp has
no explicit licence, so the data file is not redistributed with this code.

## Outputs

| Path | Content |
|---|---|
| `outputs/results.json` | every number quoted in the report |
| `outputs/tables/*.csv` | test metrics, tuning results, person-level CV, sensitivity, cold start |
| `outputs/figures/*.png` | EDA and evaluation figures (fig01–fig11) |

## Code structure

| Module | Responsibility |
|---|---|
| `sozumsoz/config.py` | every threshold and setting in one frozen dataclass |
| `sozumsoz/apps.py` | app → category mapping; target categories |
| `sozumsoz/data.py` | loading, deduplication, Opened/Closed matching, visit merging, filtering, sessions |
| `sozumsoz/promises.py` | simulated promises (four rules) and the `kept` target |
| `sozumsoz/features.py` | leakage-safe features (history, adherence, session flow, daily load, context) |
| `sozumsoz/splits.py` | chronological split, person-level folds |
| `sozumsoz/models.py` | baselines, logistic regression, random forest, LightGBM tuning, calibration |
| `sozumsoz/evaluation.py` | ROC-AUC, PR-AUC, Brier, log loss, ECE, user-level bootstrap |
| `sozumsoz/plots.py` | all figures |
| `sozumsoz/experiments.py` | EDA, main experiment, person-level CV, sensitivity, cold start |
| `run_pipeline.py` | command-line entry point |

## Key definitions

* **Visit** – one continuous period in which a single app is in the
  foreground. Built by pairing each `Opened` event with the directly
  following `Closed` event of the same app, then merging fragments of the
  same app that are at most 1 s apart.
* **Promise** – median duration of the user's earlier visits to the same app
  (at least five earlier visits required).
* **Target** – `kept = duration <= promise`.
* **Leakage rule** – every feature uses only visits that started before the
  current one (`shift(1)` inside each group).

## Reproducibility

All random seeds come from `PipelineConfig.random_state` (default 42). Results
were produced with Python 3.12, pandas 3.0, scikit-learn 1.8 and LightGBM 4.7;
the code also runs on pandas ≥ 2.1, scikit-learn ≥ 1.4 and LightGBM ≥ 4.0.
