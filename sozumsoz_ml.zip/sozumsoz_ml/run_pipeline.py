"""Run the SözümSöz data-preparation and model-exploration pipeline.

Usage
-----
    python run_pipeline.py                 # everything (about 15 minutes on one CPU)
    python run_pipeline.py --skip-robustness   # EDA + main experiment only

Outputs are written to ``outputs/``:
    results.json      every number quoted in the report
    tables/*.csv      metric tables
    figures/*.png     all figures
"""

from __future__ import annotations

import argparse
import json
import logging
import time

import numpy as np
import pandas as pd

from sozumsoz.config import DEFAULT_CONFIG, OUTPUT_DIR, RAW_DATA_PATH, TABLE_DIR
from sozumsoz.data import clean_events, load_events
from sozumsoz.experiments import (cold_start_analysis, exploratory_analysis, main_experiment,
                                  person_level_cv, prepare_table, sensitivity_analysis)

log = logging.getLogger("sozumsoz")


def _to_jsonable(obj):
    """Convert pandas / numpy objects into plain JSON types."""
    if isinstance(obj, pd.DataFrame):
        return json.loads(obj.to_json(orient="index", force_ascii=False))
    if isinstance(obj, pd.Series):
        return {str(k): _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, dict):
        return {str(k): _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(v) for v in obj]
    if isinstance(obj, np.generic):
        return obj.item()
    return obj


def _save_table(frame: pd.DataFrame, name: str) -> None:
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    frame.to_csv(TABLE_DIR / f"{name}.csv")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data", default=str(RAW_DATA_PATH), help="path to lsapp.tsv.gz")
    parser.add_argument("--skip-robustness", action="store_true",
                        help="skip person-level CV, sensitivity and cold-start analyses")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(name)-22s %(message)s", datefmt="%H:%M:%S")
    cfg = DEFAULT_CONFIG
    started = time.time()
    results: dict = {}

    # 1. Data collection and cleaning
    events, cleaning_report = clean_events(load_events(args.data))
    table, preparation_report = prepare_table(events, cfg)
    results["cleaning"] = cleaning_report
    results["preparation"] = preparation_report

    # 2. Exploratory data analysis
    results["eda"] = exploratory_analysis(events, table)

    # 3. Model exploration on the chronological split
    main = main_experiment(table, cfg)
    results["main"] = main
    _save_table(main["test_metrics"], "test_metrics")
    _save_table(main["lightgbm_search"], "lightgbm_search")
    _save_table(main["logistic_search"], "logistic_search")
    _save_table(main["importance"].to_frame("mean_abs_shap"), "shap_importance")

    # 4. Robustness: new users, alternative choices, cold start
    if not args.skip_robustness:
        best_params, best_C = main["lightgbm_best_params"], main["best_C"]

        cv = person_level_cv(table, cfg, best_params, best_C)
        _save_table(cv, "person_level_cv")
        results["person_cv"] = {
            "folds": cv,
            "summary": cv.groupby("model")[["roc_auc", "pr_auc", "brier", "ece"]].agg(["mean", "std"]),
        }

        sensitivity = sensitivity_analysis(events, cfg, best_params)
        _save_table(sensitivity, "sensitivity")
        results["sensitivity"] = sensitivity

        cold = cold_start_analysis(events, cfg, best_params)
        _save_table(cold, "cold_start")
        results["cold_start"] = cold

    results["runtime_minutes"] = round((time.time() - started) / 60, 1)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_DIR / "results.json", "w", encoding="utf-8") as handle:
        json.dump(_to_jsonable(results), handle, indent=2, ensure_ascii=False, default=str)
    log.info("Done in %.1f minutes", results["runtime_minutes"])


if __name__ == "__main__":
    main()
