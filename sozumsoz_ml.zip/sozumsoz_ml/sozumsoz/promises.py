"""Simulated duration promises and the target variable.

LSApp contains no real promises, so a promise is simulated for each visit
from the same user's *earlier* visits to the same app (concept note, Section
4). The target is

    kept = actual visit duration <= simulated promise

The simulated promise is a proxy: it does not capture the psychological
effect of actually making a promise. Results are therefore evidence about
the method, not about real promise-keeping behaviour.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .config import PROMISE_MENU_S, PipelineConfig

PROMISE_RULES = ("median", "p75", "recent10", "menu")

# Minimum number of earlier visits (all users) before an app-level
# population promise is trusted in the cold-start analysis.
MIN_POPULATION_HISTORY = 20


def _past(series_by_group, func) -> pd.Series:
    """Apply ``func`` to each group's history, excluding the current row."""
    return series_by_group.transform(lambda s: func(s.shift(1)))


def personal_promise(visits: pd.DataFrame, rule: str) -> pd.Series:
    """Promise (seconds) from the user's earlier visits to the same app.

    Rules
    -----
    median    median of all earlier durations (main analysis)
    p75       75th percentile of all earlier durations (more lenient)
    recent10  median of the 10 most recent earlier durations
    menu      the median rounded *up* to the in-app menu (1, 2, 5, 10, 15,
              30 or 60 minutes), mimicking what a user could actually pick
    """
    if rule not in PROMISE_RULES:
        raise ValueError(f"Unknown promise rule {rule!r}; choose from {PROMISE_RULES}")

    durations = visits.groupby(["user_id", "app"], sort=False)["duration_s"]
    if rule == "median":
        return _past(durations, lambda s: s.expanding().median())
    if rule == "p75":
        return _past(durations, lambda s: s.expanding().quantile(0.75))
    if rule == "recent10":
        return _past(durations, lambda s: s.rolling(10, min_periods=1).median())

    # rule == "menu": round the median up to the next menu option.
    median = _past(durations, lambda s: s.expanding().median())
    menu = np.asarray(PROMISE_MENU_S, dtype=float)
    index = np.searchsorted(menu, median.to_numpy(), side="left").clip(max=len(menu) - 1)
    return pd.Series(np.where(median.isna(), np.nan, menu[index]), index=visits.index)


def population_promise(visits: pd.DataFrame) -> pd.Series:
    """App-level fallback promise: median of all users' earlier visits.

    Used only in the cold-start analysis for users with too little personal
    history. Visits are processed in global time order, so only visits that
    started earlier contribute.
    """
    order = visits.sort_values("start", kind="mergesort")
    by_app = order.groupby("app", sort=False)["duration_s"]
    median = by_app.transform(lambda s: s.shift(1).expanding(MIN_POPULATION_HISTORY).median())
    return median.reindex(visits.index)


def add_promises(visits: pd.DataFrame, cfg: PipelineConfig) -> pd.DataFrame:
    """Add promise, outcome and labelling columns to the visit table.

    Expects visits sorted by user and start time (see ``assign_sessions``).

    Added columns
    -------------
    n_prev_app      earlier visits of this user to this app
    promise_s       simulated promise in seconds (NaN if none)
    promise_source  "personal" or "population"
    kept            1.0 if duration <= promise, 0.0 if not, NaN if no promise
    overrun_s       seconds beyond the promise (0 if kept)
    labelled        visit is used for modelling (target app with a promise)
    """
    v = visits.copy()
    v["n_prev_app"] = v.groupby(["user_id", "app"], sort=False).cumcount()

    has_history = v["n_prev_app"] >= cfg.min_history
    personal = personal_promise(v, cfg.promise_rule)
    v["promise_s"] = personal.where(has_history)
    v["promise_source"] = np.where(has_history, "personal", None)

    if cfg.cold_start:
        fallback = population_promise(v)
        use_fallback = ~has_history & fallback.notna()
        v.loc[use_fallback, "promise_s"] = fallback[use_fallback]
        v.loc[use_fallback, "promise_source"] = "population"

    has_promise = v["promise_s"].notna()
    v["kept"] = np.where(has_promise, (v["duration_s"] <= v["promise_s"]).astype(float), np.nan)
    v["overrun_s"] = (v["duration_s"] - v["promise_s"]).clip(lower=0)
    v["labelled"] = v["is_target_app"] & has_promise
    return v
