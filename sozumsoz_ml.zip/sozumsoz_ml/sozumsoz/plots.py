"""Figures for the write-up. Each function draws one figure and saves it.

All figures share one style (Okabe–Ito colour-blind-safe palette, 6.5-inch
width to fit an A4 page) so they look consistent in the report.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.metrics import precision_recall_curve, roc_curve  # noqa: E402

from .apps import TARGET_CATEGORIES  # noqa: E402
from .evaluation import reliability_curve  # noqa: E402

PALETTE = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#56B4E9", "#F0E442", "#000000"]
GREY = "#8C8C8C"
WIDTH = 6.5

plt.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 220, "savefig.bbox": "tight",
    "font.size": 9, "axes.titlesize": 9.5, "axes.titleweight": "bold",
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.alpha": 0.25, "legend.frameon": False,
})


def _save(fig, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path)
    plt.close(fig)
    return path


def _panel_label(ax, text: str) -> None:
    ax.set_title(text, loc="left")


# ---------------------------------------------------------------------------
# Exploratory data analysis
# ---------------------------------------------------------------------------
def data_coverage(events: pd.DataFrame, visits: pd.DataFrame, path: Path) -> Path:
    """Monthly volume, observed days per user and concentration across users."""
    fig, axes = plt.subplots(1, 3, figsize=(WIDTH, 2.2))

    monthly = events.set_index("timestamp").resample("MS").size()
    positions = np.arange(len(monthly))
    axes[0].bar(positions, monthly.to_numpy() / 1e3, color=PALETTE[0])
    axes[0].set_xticks(positions, monthly.index.strftime("%b %y"), rotation=60, ha="right", fontsize=6.5)
    axes[0].set_ylabel("Clean events (thousands)")
    _panel_label(axes[0], "(a) Events per month")

    days = visits.groupby("user_id")["start"].agg(lambda s: s.dt.normalize().nunique())
    axes[1].hist(days, bins=np.arange(0, days.max() + 5, 5), color=PALETTE[0])
    axes[1].axvline(days.median(), color=PALETTE[3], ls="--", lw=1, label=f"median {days.median():.0f}")
    axes[1].set_xlabel("Days with at least one visit")
    axes[1].set_ylabel("Users")
    axes[1].legend()
    _panel_label(axes[1], "(b) Observation days")

    per_user = np.sort(visits.groupby("user_id").size().to_numpy())[::-1]
    share = np.cumsum(per_user) / per_user.sum()
    axes[2].plot(np.arange(1, len(share) + 1) / len(share) * 100, share * 100, color=PALETTE[0])
    axes[2].plot([0, 100], [0, 100], color=GREY, ls=":", lw=1)
    axes[2].set_xlabel("Users, most active first (%)")
    axes[2].set_ylabel("Share of visits (%)")
    _panel_label(axes[2], "(c) Concentration")
    fig.tight_layout()
    return _save(fig, path)


def duration_distribution(visits: pd.DataFrame, path: Path) -> Path:
    """Visit durations: overall histogram and per-category spread (log scale)."""
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 2.6), gridspec_kw={"width_ratios": [1, 1.25]})
    target = visits.loc[visits["is_target_app"], "duration_s"]

    # Durations are whole seconds, so bin edges sit half-way between integers;
    # density on the log10 scale corrects for the unequal bin widths.
    edges = np.unique(np.round(np.logspace(0, np.log10(target.max()) + 0.05, 45))) - 0.5
    axes[0].hist(np.log10(target), bins=np.log10(edges), density=True, color=PALETTE[0])
    for q, label, style in [(0.5, "median", "--"), (0.9, "P90", ":")]:
        value = target.quantile(q)
        axes[0].axvline(np.log10(value), color=PALETTE[3], ls=style, lw=1, label=f"{label} {value:.0f} s")
    axes[0].set_xticks(range(0, 5), ["1", "10", "100", "1k", "10k"])
    axes[0].set_xlabel("Visit duration (s, log scale)")
    axes[0].set_ylabel("Density")
    axes[0].legend()
    _panel_label(axes[0], "(a) Target apps")

    order = (visits.groupby("category")["duration_s"].median().sort_values().index.tolist())
    data = [visits.loc[visits["category"] == c, "duration_s"] for c in order]
    box = axes[1].boxplot(data, vert=False, showfliers=False, widths=0.6, patch_artist=True,
                          medianprops={"color": "black"})
    for patch, category in zip(box["boxes"], order):
        patch.set_facecolor(PALETTE[0] if category in TARGET_CATEGORIES else "#D9D9D9")
    axes[1].set_yticks(range(1, len(order) + 1), order, fontsize=7)
    axes[1].set_xscale("log")
    axes[1].set_xlabel("Visit duration (s, log scale)")
    _panel_label(axes[1], "(b) By category (blue = target)")
    fig.tight_layout()
    return _save(fig, path)


def activity_by_time(visits: pd.DataFrame, path: Path) -> Path:
    """Share of visits by recorded hour and by weekday."""
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 2.2), gridspec_kw={"width_ratios": [2, 1]})
    hourly = visits["start"].dt.hour.value_counts(normalize=True).sort_index() * 100
    axes[0].bar(hourly.index, hourly.to_numpy(), color=PALETTE[0])
    axes[0].set_xticks(range(0, 24, 3))
    axes[0].set_xlabel("Hour as recorded in the timestamp (time zone unknown)")
    axes[0].set_ylabel("Share of visits (%)")
    _panel_label(axes[0], "(a) By hour")

    weekday = visits["start"].dt.dayofweek.value_counts(normalize=True).sort_index() * 100
    axes[1].bar(range(7), weekday.to_numpy(), color=PALETTE[0])
    axes[1].set_xticks(range(7), ["M", "T", "W", "T", "F", "S", "S"])
    axes[1].set_ylabel("Share of visits (%)")
    _panel_label(axes[1], "(b) By weekday")
    fig.tight_layout()
    return _save(fig, path)


def survival_by_category(visits: pd.DataFrame, path: Path) -> Path:
    """Empirical survival curve P(visit lasts longer than t) per target category.

    Every retained visit has an observed end (unmatched openings were
    excluded), so the Kaplan–Meier estimator reduces to 1 - ECDF.
    """
    fig, ax = plt.subplots(figsize=(WIDTH * 0.62, 2.6))
    grid = np.logspace(0, 4, 200)
    for color, category in zip(PALETTE, sorted(TARGET_CATEGORIES)):
        d = np.sort(visits.loc[visits["category"] == category, "duration_s"].to_numpy())
        survival = 1 - np.searchsorted(d, grid, side="right") / len(d)
        ax.plot(grid, survival, color=color, label=f"{category} (n={len(d):,})")
    for t, label in [(60, "1 min"), (600, "10 min")]:
        ax.axvline(t, color=GREY, ls=":", lw=1)
        ax.text(t * 1.08, 0.97, label, color=GREY, fontsize=7, va="top")
    ax.set_xscale("log")
    ax.set_xlabel("t (seconds, log scale)")
    ax.set_ylabel("P(visit lasts longer than t)")
    ax.legend(fontsize=7, loc="lower left")
    fig.tight_layout()
    return _save(fig, path)


def keep_rate_by_context(labelled: pd.DataFrame, path: Path) -> Path:
    """Keep rate of simulated promises by recent outcomes, last visit and hour.

    All panels share one y-axis range so that small differences are not
    visually exaggerated; the dotted line is the overall keep rate.
    """
    fig, axes = plt.subplots(1, 3, figsize=(WIDTH, 2.3), sharey=True)
    base = labelled["kept"].mean() * 100

    streak = labelled["streak_app"].clip(-5, 5)
    by_streak = labelled.groupby(streak)["kept"].mean() * 100
    axes[0].plot(by_streak.index, by_streak.to_numpy(), marker="o", ms=3, color=PALETTE[0])
    axes[0].set_xticks([-5, -3, -1, 1, 3, 5], ["≤−5", "−3", "−1", "+1", "+3", "≥+5"])
    axes[0].set_xlabel("Streak in this app\n(− broken, + kept in a row)")
    axes[0].set_ylabel("Promises kept (%)")
    _panel_label(axes[0], "(a) Recent outcomes")

    quintile = pd.qcut(labelled["log_last_over_promise"], 5, labels=False, duplicates="drop")
    by_last = labelled.groupby(quintile)["kept"].mean() * 100
    axes[1].plot(by_last.index + 1, by_last.to_numpy(), marker="o", ms=3, color=PALETTE[0])
    axes[1].set_xticks(range(1, 6), ["Q1\nshort", "Q2", "Q3", "Q4", "Q5\nlong"])
    axes[1].set_xlabel("Last visit relative to promise")
    _panel_label(axes[1], "(b) Last visit")

    hourly = labelled.groupby(labelled["start"].dt.hour)["kept"].mean() * 100
    axes[2].plot(hourly.index, hourly.to_numpy(), marker="o", ms=2.5, color=PALETTE[0])
    axes[2].set_xticks(range(0, 24, 6))
    axes[2].set_xlabel("Recorded hour")
    _panel_label(axes[2], "(c) Hour")

    for ax in axes:
        ax.axhline(base, color=GREY, ls=":", lw=1)
    axes[0].set_ylim(35, 70)
    fig.tight_layout()
    return _save(fig, path)


def category_transitions(transitions: pd.DataFrame, path: Path) -> Path:
    """Heatmap of P(next category | current category) within sessions."""
    fig, ax = plt.subplots(figsize=(WIDTH * 0.8, 3.6))
    matrix = transitions.to_numpy() * 100
    image = ax.imshow(matrix, cmap="Blues", vmin=0, vmax=max(40, matrix.max()))
    ax.set_xticks(range(len(transitions.columns)), transitions.columns, rotation=45, ha="right", fontsize=7)
    ax.set_yticks(range(len(transitions.index)), transitions.index, fontsize=7)
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            ax.text(j, i, f"{matrix[i, j]:.0f}", ha="center", va="center", fontsize=6.5,
                    color="white" if matrix[i, j] > 30 else "black")
    ax.set_xlabel("Next category in the same session")
    ax.set_ylabel("Current category")
    ax.grid(False)
    fig.colorbar(image, ax=ax, fraction=0.04, label="% of transitions")
    fig.tight_layout()
    return _save(fig, path)


# ---------------------------------------------------------------------------
# Model evaluation
# ---------------------------------------------------------------------------
def roc_and_pr(y_true, predictions: dict[str, np.ndarray], path: Path) -> Path:
    """ROC and precision–recall curves for several models on the same data."""
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 2.8))
    for color, (name, p) in zip(PALETTE, predictions.items()):
        fpr, tpr, _ = roc_curve(y_true, p)
        precision, recall, _ = precision_recall_curve(y_true, p)
        axes[0].plot(fpr, tpr, color=color, lw=1.3, label=name)
        axes[1].plot(recall, precision, color=color, lw=1.3, label=name)
    axes[0].plot([0, 1], [0, 1], color=GREY, ls=":", lw=1)
    axes[0].set_xlabel("False positive rate")
    axes[0].set_ylabel("True positive rate")
    _panel_label(axes[0], "(a) ROC curve")
    axes[0].legend(fontsize=7, loc="lower right")
    axes[1].axhline(np.mean(y_true), color=GREY, ls=":", lw=1)
    axes[1].set_xlabel("Recall (kept)")
    axes[1].set_ylabel("Precision (kept)")
    _panel_label(axes[1], "(b) Precision–recall curve")
    fig.tight_layout()
    return _save(fig, path)


def reliability(y_true, predictions: dict[str, np.ndarray], path: Path) -> Path:
    """Reliability diagram plus the distribution of predicted probabilities."""
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 2.8), gridspec_kw={"width_ratios": [1.2, 1]})
    axes[0].plot([0, 1], [0, 1], color=GREY, ls=":", lw=1, label="perfect calibration")
    for color, (name, p) in zip(PALETTE, predictions.items()):
        curve = reliability_curve(y_true, p)
        curve = curve[curve["n"] >= 30]
        axes[0].plot(curve["mean_predicted"], curve["observed"], marker="o", ms=3, color=color, label=name)
        axes[1].hist(p, bins=np.linspace(0, 1, 26), histtype="step", lw=1.2, color=color)
    axes[0].set_xlabel("Predicted P(kept)")
    axes[0].set_ylabel("Observed keep rate")
    axes[0].legend(fontsize=7)
    _panel_label(axes[0], "(a) Reliability diagram")
    axes[1].set_xlabel("Predicted P(kept)")
    axes[1].set_ylabel("Test visits")
    _panel_label(axes[1], "(b) Spread of predictions")
    fig.tight_layout()
    return _save(fig, path)


def confusion(matrix: pd.DataFrame, path: Path) -> Path:
    """Confusion matrix with counts and row percentages."""
    fig, ax = plt.subplots(figsize=(WIDTH * 0.5, 2.4))
    counts = matrix.to_numpy()
    row_share = counts / counts.sum(axis=1, keepdims=True)
    ax.imshow(row_share, cmap="Blues", vmin=0, vmax=1)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{counts[i, j]:,}\n({row_share[i, j]:.0%})", ha="center", va="center",
                    fontsize=8, color="white" if row_share[i, j] > 0.5 else "black")
    ax.set_xticks([0, 1], ["Broken", "Kept"])
    ax.set_yticks([0, 1], ["Broken", "Kept"])
    ax.set_xlabel("Predicted (threshold 0.5)")
    ax.set_ylabel("Actual")
    ax.grid(False)
    fig.tight_layout()
    return _save(fig, path)


def feature_importance(importance: pd.Series, path: Path, top: int = 15) -> Path:
    """Mean absolute SHAP value per feature (log-odds scale)."""
    data = importance.sort_values(ascending=True).tail(top)
    fig, ax = plt.subplots(figsize=(WIDTH * 0.75, 3.2))
    ax.barh(data.index, data.to_numpy(), color=PALETTE[0])
    ax.set_xlabel("Mean |SHAP value| (log-odds)")
    ax.tick_params(axis="y", labelsize=7.5)
    fig.tight_layout()
    return _save(fig, path)


def history_buckets(table: pd.DataFrame, path: Path) -> Path:
    """Test ROC-AUC with 95% user-level bootstrap CI by amount of personal history."""
    fig, ax = plt.subplots(figsize=(WIDTH * 0.62, 2.5))
    x = np.arange(len(table))
    error = [table["roc_auc"] - table["roc_auc_low"], table["roc_auc_high"] - table["roc_auc"]]
    ax.bar(x, table["roc_auc"], color=PALETTE[0], width=0.6)
    ax.errorbar(x, table["roc_auc"], yerr=error, fmt="none", ecolor="black", capsize=3, lw=1)
    for i, (high, n) in enumerate(zip(table["roc_auc_high"], table["n"])):
        ax.text(i, high + 0.01, f"n={n:,}", ha="center", fontsize=7)
    ax.set_xticks(x, table.index)
    ax.set_ylim(0.5, 0.8)
    ax.set_xlabel("Earlier visits of the user to this app")
    ax.set_ylabel("ROC-AUC (test)")
    fig.tight_layout()
    return _save(fig, path)
