"""Loading, cleaning and visit construction for LSApp.

Pipeline (each step is one function, so it can be tested and reported):

    load_events      raw TSV inside the downloaded archive -> event table
    clean_events     drop exact duplicates and incomplete rows
    build_visits     Opened/Closed matching -> fragments -> continuous visits
    filter_visits    remove artefacts and implausible durations
    assign_sessions  group visits into phone sessions (5-minute gap rule)

A *visit* is one continuous period in which a single app is in the
foreground. It is the unit for which SözümSöz would ask for a promise.
"""

from __future__ import annotations

import logging
import tarfile
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd

from .apps import TARGET_CATEGORIES, category_of
from .config import RAW_DATA_PATH, RAW_DATA_URL, PipelineConfig

log = logging.getLogger(__name__)

RAW_COLUMNS = ["user_id", "session_id", "timestamp", "app_name", "event_type"]
EVENT_TYPES = ["Opened", "Closed", "User Interaction", "Broken"]


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def download_raw(path: Path = RAW_DATA_PATH, url: str = RAW_DATA_URL) -> Path:
    """Download the LSApp archive from the official repository if missing."""
    path = Path(path)
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        log.info("Downloading LSApp from %s", url)
        urllib.request.urlretrieve(url, path)
    return path


def load_events(path: Path = RAW_DATA_PATH) -> pd.DataFrame:
    """Read the raw LSApp event log.

    The file published as ``lsapp.tsv.gz`` is in fact a gzip-compressed *tar*
    archive that contains ``lsapp.tsv``. Reading it as a plain gzip file
    merges the tar header into the first line (the "row with missing fields"
    mentioned in the concept note), so the TSV member is read from the
    archive instead.

    Returns one row per raw event, in file order, plus ``row_order`` which
    is used as a stable tie-breaker for events with the same timestamp.
    """
    path = download_raw(path)
    dtypes = {"user_id": "int32", "session_id": "int32",
              "app_name": "category", "event_type": "category"}

    if tarfile.is_tarfile(path):
        with tarfile.open(path, mode="r:gz") as archive:
            member = next(m for m in archive.getmembers() if m.name.endswith(".tsv"))
            with archive.extractfile(member) as handle:
                events = pd.read_csv(handle, sep="\t", dtype=dtypes)
    else:  # an already extracted (optionally gzip-compressed) TSV
        events = pd.read_csv(path, sep="\t", dtype=dtypes)

    events = events[RAW_COLUMNS]
    events["timestamp"] = pd.to_datetime(events["timestamp"], format="%Y-%m-%d %H:%M:%S")
    events["row_order"] = np.arange(len(events), dtype=np.int64)
    log.info("Loaded %s raw rows", f"{len(events):,}")
    return events


# ---------------------------------------------------------------------------
# Cleaning
# ---------------------------------------------------------------------------
def clean_events(events: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Remove exact duplicate rows and rows with missing fields.

    Two rows are duplicates only if *all five* original fields are equal;
    the first occurrence (in file order) is kept.
    """
    report = {"raw_rows": len(events)}

    incomplete = events[RAW_COLUMNS].isna().any(axis=1)
    events = events.loc[~incomplete]
    report["incomplete_rows"] = int(incomplete.sum())

    duplicated = events.duplicated(subset=RAW_COLUMNS, keep="first")
    events = events.loc[~duplicated].reset_index(drop=True)
    report["duplicate_rows"] = int(duplicated.sum())
    report["clean_rows"] = len(events)
    report["event_type_counts"] = (
        events["event_type"].value_counts().reindex(EVENT_TYPES).fillna(0).astype(int).to_dict()
    )
    report["users"] = int(events["user_id"].nunique())
    report["apps"] = int(events["app_name"].nunique())
    report["lsapp_sessions"] = int(events.groupby("user_id")["session_id"].nunique().sum())
    report["first_event"] = str(events["timestamp"].min())
    report["last_event"] = str(events["timestamp"].max())
    log.info("Cleaning: %s duplicates removed, %s rows left",
             f"{report['duplicate_rows']:,}", f"{report['clean_rows']:,}")
    return events, report


# ---------------------------------------------------------------------------
# Visit construction
# ---------------------------------------------------------------------------
def match_fragments(events: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Pair every Opened event with the Closed event that directly follows it.

    Events are ordered chronologically per (user, app). An Opened event forms
    a *fragment* only if the next Opened/Closed event of the same app is a
    Closed event. An Opened event followed by another Opened event has no
    reliable end time (typically the screen was switched off), so it is not
    matched; following the concept note, it is not treated as a censored
    observation either. User Interaction and Broken events are logging
    categories and do not define usage time.
    """
    oc = events.loc[events["event_type"].isin(["Opened", "Closed"]),
                    ["user_id", "session_id", "app_name", "event_type", "timestamp", "row_order"]]
    oc = oc.sort_values(["user_id", "app_name", "timestamp", "row_order"], kind="mergesort")

    by_user_app = oc.groupby(["user_id", "app_name"], sort=False, observed=True)
    next_type = by_user_app["event_type"].shift(-1)
    next_time = by_user_app["timestamp"].shift(-1)

    is_opened = oc["event_type"].eq("Opened")
    matched = is_opened & next_type.eq("Closed")

    fragments = oc.loc[matched, ["user_id", "session_id", "app_name", "timestamp", "row_order"]].copy()
    fragments = fragments.rename(columns={"timestamp": "start"})
    fragments["end"] = next_time[matched]

    report = {
        "opened_events": int(is_opened.sum()),
        "fragments": len(fragments),
        "unmatched_opened": int(is_opened.sum() - matched.sum()),
    }
    return fragments, report


def merge_fragments(fragments: pd.DataFrame, merge_gap_s: float) -> pd.DataFrame:
    """Merge consecutive fragments of the same app into continuous visits.

    Fragments are ordered per user in time. A fragment continues the current
    visit if it belongs to the same app as the previous fragment *of that
    user* and starts at most ``merge_gap_s`` seconds after it ended. Any
    other app in between therefore always ends a visit.
    """
    f = fragments.sort_values(["user_id", "start", "row_order"], kind="mergesort").reset_index(drop=True)
    by_user = f.groupby("user_id", sort=False)

    same_app = by_user["app_name"].shift(1).eq(f["app_name"])
    gap_s = (f["start"] - by_user["end"].shift(1)).dt.total_seconds()
    continues_visit = same_app & gap_s.le(merge_gap_s)
    visit_id = (~continues_visit).cumsum()

    visits = f.groupby(visit_id, sort=False).agg(
        user_id=("user_id", "first"),
        lsapp_session_id=("session_id", "first"),
        app=("app_name", "first"),
        start=("start", "first"),
        end=("end", "max"),
        n_fragments=("start", "size"),
    )
    visits["app"] = visits["app"].astype(str)
    visits["duration_s"] = (visits["end"] - visits["start"]).dt.total_seconds()
    return visits.reset_index(drop=True)


def filter_visits(visits: pd.DataFrame, cfg: PipelineConfig) -> tuple[pd.DataFrame, dict]:
    """Remove zero-length artefacts and implausibly long visits; add categories."""
    too_short = visits["duration_s"] < cfg.min_visit_s
    too_long = visits["duration_s"] > cfg.max_visit_s
    kept = visits.loc[~too_short & ~too_long].copy()

    kept["category"] = kept["app"].map(category_of)
    kept["is_target_app"] = kept["category"].isin(TARGET_CATEGORIES)

    report = {
        "visits_before_filter": len(visits),
        "removed_too_short": int(too_short.sum()),
        "removed_too_long": int(too_long.sum()),
        "visits": len(kept),
        "target_app_visits": int(kept["is_target_app"].sum()),
    }
    return kept.reset_index(drop=True), report


def assign_sessions(visits: pd.DataFrame, gap_s: float) -> pd.DataFrame:
    """Group visits into phone sessions using an inactivity-gap rule.

    A new session starts when a visit begins more than ``gap_s`` seconds
    after the latest end time of the user's earlier visits. Using the running
    maximum of end times keeps overlapping visits in the same session.
    """
    v = visits.sort_values(["user_id", "start", "end"], kind="mergesort").reset_index(drop=True)
    latest_end = v.groupby("user_id", sort=False)["end"].transform(
        lambda s: s.cummax().shift(1)
    )
    new_session = latest_end.isna() | ((v["start"] - latest_end).dt.total_seconds() > gap_s)
    v["session"] = new_session.cumsum().astype(np.int64)
    return v


def build_visits(events: pd.DataFrame, cfg: PipelineConfig) -> tuple[pd.DataFrame, dict]:
    """Run the full visit-construction chain on cleaned events."""
    fragments, match_report = match_fragments(events)
    visits = merge_fragments(fragments, cfg.merge_gap_s)
    visits, filter_report = filter_visits(visits, cfg)
    visits = assign_sessions(visits, cfg.session_gap_s)
    report = {**match_report, **filter_report, "sessions": int(visits["session"].nunique())}
    log.info("Built %s visits (%s in target apps)",
             f"{report['visits']:,}", f"{report['target_app_visits']:,}")
    return visits, report
