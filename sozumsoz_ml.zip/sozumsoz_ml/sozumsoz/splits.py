"""Train/validation/test splits.

Two questions are evaluated separately (concept note, Section 4):

1. *Known users, future behaviour* – a chronological split. The model is
   trained on the earlier 80% of labelled visits and tested on the last
   20%; the last part of the training period is held out as validation for
   tuning, early stopping and calibration.
2. *New users* – person-level cross-validation. A user's visits are never
   in both the training and the test fold.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold


@dataclass(frozen=True)
class ChronologicalSplit:
    """Row positions of each part plus the two cut-off times."""

    train: np.ndarray
    validation: np.ndarray
    test: np.ndarray
    validation_start: pd.Timestamp
    test_start: pd.Timestamp


def _cutoff(start_times: pd.Series, fraction_after: float) -> pd.Timestamp:
    """Earliest start time of the last ``fraction_after`` share of rows."""
    ordered = start_times.sort_values(kind="mergesort").to_numpy()
    position = int(np.floor(len(ordered) * (1.0 - fraction_after)))
    return pd.Timestamp(ordered[position])


def chronological_split(start_times: pd.Series, test_fraction: float,
                        validation_fraction: float) -> ChronologicalSplit:
    """Split rows by start time into train / validation / test.

    Rows that start at or after the test cut-off form the test set. Within
    the remaining rows, the last ``validation_fraction`` form the
    validation set. Positions refer to the order of ``start_times``.
    """
    start_times = start_times.reset_index(drop=True)
    test_start = _cutoff(start_times, test_fraction)
    is_test = start_times >= test_start

    validation_start = _cutoff(start_times[~is_test], validation_fraction)
    is_validation = ~is_test & (start_times >= validation_start)
    is_train = ~is_test & ~is_validation

    return ChronologicalSplit(
        train=np.flatnonzero(is_train),
        validation=np.flatnonzero(is_validation),
        test=np.flatnonzero(is_test),
        validation_start=validation_start,
        test_start=test_start,
    )


def person_folds(groups: pd.Series, n_folds: int) -> list[tuple[np.ndarray, np.ndarray]]:
    """Person-level folds: (train positions, test positions) per fold."""
    splitter = GroupKFold(n_splits=n_folds)
    dummy = np.zeros(len(groups))
    return [(train, test) for train, test in splitter.split(dummy, groups=groups.to_numpy())]


def hold_out_users(groups: pd.Series, positions: np.ndarray, fraction: float,
                   seed: int) -> tuple[np.ndarray, np.ndarray]:
    """Split ``positions`` into (fit, hold-out) by randomly chosen users.

    Used inside person-level CV to obtain an early-stopping / calibration set
    that, like the test fold, contains only unseen users.
    """
    users = groups.to_numpy()[positions]
    unique_users = np.unique(users)
    rng = np.random.default_rng(seed)
    n_hold = max(1, int(round(len(unique_users) * fraction)))
    held = rng.choice(unique_users, size=n_hold, replace=False)
    is_held = np.isin(users, held)
    return positions[~is_held], positions[is_held]
