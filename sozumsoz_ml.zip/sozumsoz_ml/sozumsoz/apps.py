"""App categories for the 87 apps in LSApp.

LSApp has no app metadata, so the team assigned each app to one functional
category by hand. The categories serve two purposes:

1. They define the *target apps* for which a duration promise is simulated.
   Following the concept note, these are the categories in which users most
   often lose track of time: social media and feeds, messaging, video and
   streaming, and games. A promise screen in front of the phone dialler,
   the camera or the settings app would make no sense.
2. They provide a coarse, low-cardinality context feature (e.g. "the
   previous app in this session was a browser").

Any app missing from the mapping falls back to ``OTHER`` so that new apps in
the prototype never break the pipeline.
"""

from __future__ import annotations

SOCIAL = "Social & feeds"
MESSAGING = "Messaging"
VIDEO = "Video & streaming"
GAMES = "Games"
BROWSER = "Browser & search"
EMAIL = "Email"
SHOPPING = "Shopping & finance"
REWARDS = "Rewards & lock screen"
MUSIC = "Music & audio"
CALLS = "Calls & contacts"
PHOTOS = "Camera & photos"
NAVIGATION = "Navigation"
TOOLS = "Productivity & tools"
SYSTEM = "System & store"
OTHER = "Other"

TARGET_CATEGORIES: frozenset[str] = frozenset({SOCIAL, MESSAGING, VIDEO, GAMES})

APP_CATEGORY: dict[str, str] = {
    # Social media and feeds
    "Facebook": SOCIAL, "Instagram": SOCIAL, "Twitter": SOCIAL,
    "Reddit": SOCIAL, "Snapchat": SOCIAL, "Pinterest": SOCIAL,
    "Quora": SOCIAL, "Badoo": SOCIAL, "Flipboard Briefing": SOCIAL,
    # Messaging
    "Facebook Messenger": MESSAGING, "Messages": MESSAGING,
    "Telegram": MESSAGING, "Telegram X": MESSAGING,
    "Verizon Messages": MESSAGING, "WhatsApp Messenger": MESSAGING,
    "Messaging": MESSAGING, "Hangouts": MESSAGING, "imo": MESSAGING,
    "Discord": MESSAGING, "WeChat": MESSAGING, "Messenger Lite": MESSAGING,
    "Kik": MESSAGING, "TextNow": MESSAGING, "Text One": MESSAGING,
    # Video and streaming
    "YouTube": VIDEO, "Netflix": VIDEO, "Hulu": VIDEO, "Movie Play Box": VIDEO,
    # Games
    "Minesweeper Classic (Mines)": GAMES, "Words With Friends 2": GAMES,
    "Army Men Strike": GAMES, "Baseball Boy!": GAMES, "Lucktastic": GAMES,
    # Browser and search
    "Google Chrome": BROWSER, "Google": BROWSER,
    "Samsung Internet Browser": BROWSER, "Microsoft Bing Search": BROWSER,
    "Brave Browser": BROWSER,
    # Email
    "Gmail": EMAIL, "Samsung Email": EMAIL, "Yahoo Mail": EMAIL,
    "Microsoft Outlook": EMAIL, "AOL": EMAIL,
    # Shopping and finance
    "Amazon Shopping": SHOPPING, "eBay": SHOPPING, "Walmart": SHOPPING,
    "OfferUp": SHOPPING, "Ibotta": SHOPPING, "Receipt Hog": SHOPPING,
    "PayPal Mobile Cash": SHOPPING, "Robinhood": SHOPPING,
    "Samsung Pay": SHOPPING,
    # Rewards apps and lock-screen apps (shown automatically, not chosen)
    "S’more": REWARDS, "Slidejoy": REWARDS, "SurveyCow": REWARDS,
    "Reward Stash": REWARDS, "Swagbucks": REWARDS,
    "Swagbucks Watch (TV)": REWARDS, "EntertaiNow": REWARDS,
    "The PCH App": REWARDS, "MUIQ Survey App": REWARDS,
    # Music and audio (mostly background playback)
    "Spotify Music": MUSIC, "Google Play Music": MUSIC,
    "Pandora Music": MUSIC, "Podcast Addict": MUSIC,
    # Calls and contacts
    "Phone": CALLS, "Android In Call UI": CALLS, "Contacts": CALLS,
    # Camera and photos
    "Camera": PHOTOS, "Samsung Gallery": PHOTOS, "Google Photos": PHOTOS,
    "Pixlr": PHOTOS, "Flickr": PHOTOS, "Faceu": PHOTOS,
    # Navigation
    "Maps": NAVIGATION, "MetroZone": NAVIGATION,
    "DigiHUD Pro Speedometer": NAVIGATION,
    # Productivity and tools
    "Calendar": TOOLS, "Clock": TOOLS, "Calculator": TOOLS,
    "Google Drive": TOOLS, "Samsung Notes": TOOLS, "Calorie Counter": TOOLS,
    # System, store and cleaners
    "Settings": SYSTEM, "Google Play Store": SYSTEM,
    "MAX Cleaner": SYSTEM, "Clean Master": SYSTEM,
}


def category_of(app_name: str) -> str:
    """Return the functional category of an app (``OTHER`` if unknown)."""
    return APP_CATEGORY.get(app_name, OTHER)
