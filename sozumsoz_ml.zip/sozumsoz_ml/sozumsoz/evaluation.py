"""Evaluation metrics.

Discrimination   ROC-AUC, PR-AUC (average precision)
Probability      Brier score, log loss, expected calibration error (ECE)
Decision (0.5)   accuracy and the confusion matrix

The Brier score mixes discrimination and calibration, so ECE and the
reliability curve are reported as well (concept note, Section 4).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import (average_precision_score, brier_score_loss, confusion_matrix,
                             log_loss, roc_auc_score)


def expected_calibration_error(y_true, p, n_bins: int = 10) -> float:
    """ECE with equal-width bins: sum_b (n_b / n) * |mean(y)_b - mean(p)_b|."""
    y_true, p = np.asarray(y_true, dtype=float), np.asarray(p, dtype=float)
    bins = np.minimum((p * n_bins).astype(int), n_bins - 1)
    ece = 0.0
    for b in range(n_bins):
        in_bin = bins == b
        if in_bin.any():
            ece += in_bin.mean() * abs(y_true[in_bin].mean() - p[in_bin].mean())
    return float(ece)


def reliability_curve(y_true, p, n_bins: int = 10) -> pd.DataFrame:
    """Mean predicted vs observed keep rate per equal-width probability bin."""
    frame = pd.DataFrame({"y": np.asarray(y_true, float), "p": np.asarray(p, float)})
    frame["bin"] = np.minimum((frame["p"] * n_bins).astype(int), n_bins - 1)
    return (frame.groupby("bin")
            .agg(mean_predicted=("p", "mean"), observed=("y", "mean"), n=("y", "size"))
            .reset_index())


def classification_metrics(y_true, p, threshold: float = 0.5) -> dict:
    """All headline metrics for one model on one dataset."""
    y_true, p = np.asarray(y_true), np.asarray(p, dtype=float)
    p_clipped = np.clip(p, 1e-6, 1 - 1e-6)
    return {
        "n": int(len(y_true)),
        "keep_rate": float(y_true.mean()),
        "roc_auc": float(roc_auc_score(y_true, p)) if len(np.unique(y_true)) > 1 else np.nan,
        "pr_auc": float(average_precision_score(y_true, p)),
        "brier": float(brier_score_loss(y_true, p)),
        "log_loss": float(log_loss(y_true, p_clipped, labels=[0, 1])),
        "ece": expected_calibration_error(y_true, p),
        "accuracy": float(((p >= threshold).astype(int) == y_true).mean()),
    }


def confusion_table(y_true, p, threshold: float = 0.5) -> pd.DataFrame:
    """Confusion matrix with readable labels (rows = actual outcome)."""
    labels = ["Broken (0)", "Kept (1)"]
    matrix = confusion_matrix(y_true, (np.asarray(p) >= threshold).astype(int), labels=[0, 1])
    return pd.DataFrame(matrix, index=[f"Actual {l}" for l in labels],
                        columns=[f"Predicted {l}" for l in labels])


def cluster_bootstrap_ci(y_true, p, groups, metric=roc_auc_score, n_boot: int = 300,
                         seed: int = 42, alpha: float = 0.05) -> tuple[float, float]:
    """Percentile CI that resamples *users*, not visits.

    Visits of the same user are correlated, so resampling individual visits
    would make the interval too narrow.
    """
    y_true, p, groups = np.asarray(y_true), np.asarray(p), np.asarray(groups)
    users, inverse = np.unique(groups, return_inverse=True)
    rows_by_user = [np.flatnonzero(inverse == i) for i in range(len(users))]
    rng = np.random.default_rng(seed)

    estimates = []
    for _ in range(n_boot):
        sampled = rng.integers(0, len(users), size=len(users))
        idx = np.concatenate([rows_by_user[i] for i in sampled])
        if len(np.unique(y_true[idx])) == 2:
            estimates.append(metric(y_true[idx], p[idx]))
    low, high = np.quantile(estimates, [alpha / 2, 1 - alpha / 2])
    return float(low), float(high)


def overrun_summary(table: pd.DataFrame) -> dict:
    """Keep rate together with actual use and the size of broken promises.

    A high keep rate obtained by simply promising longer durations is not a
    success, so it is always reported next to promised and actual time.
    """
    broken = table.loc[table["kept"] == 0]
    return {
        "n": int(len(table)),
        "keep_rate": float(table["kept"].mean()),
        "median_promise_s": float(table["promise_s"].median()),
        "median_duration_s": float(table["duration_s"].median()),
        "median_overrun_s_if_broken": float(broken["overrun_s"].median()),
        "p90_overrun_s_if_broken": float(broken["overrun_s"].quantile(0.9)),
        "median_overrun_ratio_if_broken": float((broken["duration_s"] / broken["promise_s"]).median()),
        "share_of_time_beyond_promise": float(table["overrun_s"].sum() / table["duration_s"].sum()),
    }
