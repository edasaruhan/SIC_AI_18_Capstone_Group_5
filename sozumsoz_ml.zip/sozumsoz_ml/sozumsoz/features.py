"""Feature engineering.

Every feature describes what the app would know *at the moment the user
opens the target app*: earlier visits, earlier outcomes, the current session
so far and the clock. Nothing is computed from the current visit or from
later visits; history features always use ``shift(1)`` inside the relevant
group. This is the main protection against leakage.

The same features can be computed on a phone from the prototype's own
usage log (feature parity), which matters for the planned pilot.

Feature groups
--------------
Promise          log_promise, n_prev_app
App history      log_last_dur_app, mean_log_dur_last5_app,
                 std_log_dur_last5_app, log_last_over_promise,
                 log_secs_since_last_app
Adherence        keep_rate_app_prior, keep_rate_app_last5, streak_app,
                 user_keep_rate_prior
Session flow     log_secs_since_prev_visit, log_prev_visit_dur,
                 visit_idx_in_session, log_secs_since_session_start,
                 n_distinct_apps_session, prev_category
Daily load       n_visits_today, log_secs_used_today
Context          hour, day_of_week, app, category
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .apps import APP_CATEGORY, OTHER

SESSION_START = "Session start"

NUMERIC_FEATURES: list[str] = [
    # promise
    "log_promise", "n_prev_app",
    # app history
    "log_last_dur_app", "mean_log_dur_last5_app", "std_log_dur_last5_app",
    "log_last_over_promise", "log_secs_since_last_app",
    # adherence
    "keep_rate_app_prior", "keep_rate_app_last5", "streak_app", "user_keep_rate_prior",
    # session flow
    "log_secs_since_prev_visit", "log_prev_visit_dur", "visit_idx_in_session",
    "log_secs_since_session_start", "n_distinct_apps_session",
    # daily load
    "n_visits_today", "log_secs_used_today",
    # context
    "hour", "day_of_week",
]
CATEGORICAL_FEATURES: list[str] = ["app", "category", "prev_category"]
CYCLIC_FEATURES: dict[str, int] = {"hour": 24, "day_of_week": 7}
FEATURES: list[str] = NUMERIC_FEATURES + CATEGORICAL_FEATURES

# Fixed category levels, so that train, validation, test and new data
# always share the same encoding.
_ALL_CATEGORIES = sorted(set(APP_CATEGORY.values()) | {OTHER})
CATEGORY_LEVELS: dict[str, list[str]] = {
    "app": sorted(APP_CATEGORY),
    "category": _ALL_CATEGORIES,
    "prev_category": _ALL_CATEGORIES + [SESSION_START],
}


def _signed_streak(outcomes: pd.Series) -> pd.Series:
    """Streak *before* each visit: +k after k kept promises in a row, -k after
    k broken ones. Visits without a promise leave the streak unchanged."""
    result = np.zeros(len(outcomes))
    streak = 0.0
    for i, outcome in enumerate(outcomes.to_numpy()):
        result[i] = streak
        if np.isnan(outcome):
            continue
        if outcome == 1.0:
            streak = streak + 1 if streak > 0 else 1.0
        else:
            streak = streak - 1 if streak < 0 else -1.0
    return pd.Series(result, index=outcomes.index)


def _add_app_history(v: pd.DataFrame) -> None:
    """Features from the user's earlier visits to the same app."""
    by_user_app = v.groupby(["user_id", "app"], sort=False)
    log_dur = np.log1p(v["duration_s"])
    prev_log_dur = log_dur.groupby([v["user_id"], v["app"]], sort=False).shift(1)
    by_prev = prev_log_dur.groupby([v["user_id"], v["app"]], sort=False)

    v["log_promise"] = np.log1p(v["promise_s"])
    v["log_last_dur_app"] = prev_log_dur
    v["mean_log_dur_last5_app"] = by_prev.transform(lambda s: s.rolling(5, min_periods=1).mean())
    v["std_log_dur_last5_app"] = by_prev.transform(lambda s: s.rolling(5, min_periods=2).std())
    v["log_last_over_promise"] = prev_log_dur - v["log_promise"]

    prev_end = by_user_app["end"].shift(1)
    v["log_secs_since_last_app"] = np.log1p((v["start"] - prev_end).dt.total_seconds().clip(lower=0))


def _add_adherence(v: pd.DataFrame) -> None:
    """Features from the user's earlier (simulated) promise outcomes.

    ``user_keep_rate_prior`` is the data-driven counterpart of the concept
    note's "trust score": the share of all earlier promises the user kept.
    """
    prev_kept_app = v.groupby(["user_id", "app"], sort=False)["kept"].shift(1)
    by_app = prev_kept_app.groupby([v["user_id"], v["app"]], sort=False)
    v["keep_rate_app_prior"] = by_app.transform(lambda s: s.expanding().mean())
    v["keep_rate_app_last5"] = by_app.transform(lambda s: s.rolling(5, min_periods=1).mean())
    v["streak_app"] = v.groupby(["user_id", "app"], sort=False)["kept"].transform(_signed_streak)

    prev_kept_user = v.groupby("user_id", sort=False)["kept"].shift(1)
    v["user_keep_rate_prior"] = prev_kept_user.groupby(v["user_id"], sort=False).transform(
        lambda s: s.expanding().mean()
    )


def _add_session_flow(v: pd.DataFrame) -> None:
    """Features describing the phone session up to the current visit."""
    by_user = v.groupby("user_id", sort=False)
    prev_end = by_user["end"].shift(1)
    overlaps = prev_end > v["start"]  # previous visit still running: duration unknown

    v["log_secs_since_prev_visit"] = np.log1p((v["start"] - prev_end).dt.total_seconds().clip(lower=0))
    v["log_prev_visit_dur"] = np.log1p(by_user["duration_s"].shift(1).where(~overlaps))

    by_session = v.groupby("session", sort=False)
    v["visit_idx_in_session"] = by_session.cumcount()
    v["log_secs_since_session_start"] = np.log1p(
        (v["start"] - by_session["start"].transform("first")).dt.total_seconds()
    )
    first_time_in_session = ~v.duplicated(subset=["session", "app"])
    v["n_distinct_apps_session"] = (
        first_time_in_session.groupby(v["session"], sort=False).cumsum() - first_time_in_session
    )
    v["prev_category"] = by_session["category"].shift(1).fillna(SESSION_START)


def _add_daily_load_and_context(v: pd.DataFrame) -> None:
    """How much the phone has been used today so far, plus clock features."""
    day = v["start"].dt.normalize()
    by_day = v.groupby([v["user_id"], day], sort=False)
    v["n_visits_today"] = by_day.cumcount()
    v["log_secs_used_today"] = np.log1p(by_day["duration_s"].cumsum() - v["duration_s"])
    v["hour"] = v["start"].dt.hour
    v["day_of_week"] = v["start"].dt.dayofweek


def add_features(visits: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of the visit table with all model features added.

    Expects the output of ``promises.add_promises`` (sorted by user and
    start time). Features are computed for *all* visits, so that non-target
    apps still contribute session context; only labelled rows are modelled.
    """
    v = visits.sort_values(["user_id", "start", "end"], kind="mergesort").reset_index(drop=True)
    _add_app_history(v)
    _add_adherence(v)
    _add_session_flow(v)
    _add_daily_load_and_context(v)
    return v


def to_model_frame(table: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Select labelled rows and return (X, y) with fixed categorical levels."""
    rows = table.loc[table["labelled"]]
    X = rows[FEATURES].copy()
    for column, levels in CATEGORY_LEVELS.items():
        X[column] = pd.Categorical(X[column], categories=levels)
    y = rows["kept"].astype(int)
    return X, y
