"""Models: two baselines, logistic regression, random forest and LightGBM.

All models expose ``predict_proba(X)[:, 1]`` = P(promise kept), so the
evaluation code treats them identically.

* ``MajorityBaseline``  – always predicts the training keep rate
* ``HistoryBaseline``   – the user's own past keep rate in this app
* logistic regression    – interpretable linear baseline (scikit-learn)
* random forest          – a second tree ensemble, for comparison
* LightGBM               – main model; calibrated with isotonic regression
"""

from __future__ import annotations

import itertools
import logging
import warnings
from dataclasses import dataclass

import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, OrdinalEncoder, StandardScaler

from .config import LightGBMSearchSpace, LogisticSearchSpace
from .features import CATEGORICAL_FEATURES, CATEGORY_LEVELS, CYCLIC_FEATURES, NUMERIC_FEATURES

log = logging.getLogger(__name__)

LINEAR_NUMERIC = [f for f in NUMERIC_FEATURES if f not in CYCLIC_FEATURES]


# ---------------------------------------------------------------------------
# Baselines
# ---------------------------------------------------------------------------
class MajorityBaseline:
    """Predicts the training keep rate for every visit ("always kept")."""

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "MajorityBaseline":
        self.rate_ = float(np.mean(y))
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        p = np.full(len(X), self.rate_)
        return np.column_stack([1 - p, p])


class HistoryBaseline:
    """The user's own past keep rate in this app, then across apps.

    This is the simplest personalised rule a product could use without any
    machine learning: "you kept 60% of your promises here, so 60%".
    """

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "HistoryBaseline":
        self.rate_ = float(np.mean(y))
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        p = (X["keep_rate_app_prior"]
             .fillna(X["user_keep_rate_prior"])
             .fillna(self.rate_)
             .to_numpy(dtype=float))
        return np.column_stack([1 - p, p])


# ---------------------------------------------------------------------------
# Logistic regression
# ---------------------------------------------------------------------------
def _cyclic_encode(frame: pd.DataFrame) -> np.ndarray:
    """Encode hour and weekday as points on a circle (23:00 is close to 00:00)."""
    columns = []
    for name, period in CYCLIC_FEATURES.items():
        angle = 2 * np.pi * frame[name].to_numpy(dtype=float) / period
        columns += [np.sin(angle), np.cos(angle)]
    return np.column_stack(columns)


def _cyclic_names(transformer, input_features) -> list[str]:
    return [f"{name}_{fn}" for name in CYCLIC_FEATURES for fn in ("sin", "cos")]


def make_logistic(C: float = 1.0, random_state: int = 42) -> Pipeline:
    """Logistic regression with imputation, scaling and one-hot encoding."""
    preprocess = ColumnTransformer([
        ("numeric", Pipeline([
            ("impute", SimpleImputer(strategy="median", add_indicator=True)),
            ("scale", StandardScaler()),
        ]), LINEAR_NUMERIC),
        ("cyclic", FunctionTransformer(_cyclic_encode, feature_names_out=_cyclic_names),
         list(CYCLIC_FEATURES)),
        ("categorical", OneHotEncoder(
            categories=[CATEGORY_LEVELS[c] for c in CATEGORICAL_FEATURES],
            handle_unknown="ignore", sparse_output=False,
        ), CATEGORICAL_FEATURES),
    ])
    return Pipeline([
        ("preprocess", preprocess),
        ("model", LogisticRegression(C=C, max_iter=2000, random_state=random_state)),
    ])


def tune_logistic(X_train, y_train, X_val, y_val,
                  space: LogisticSearchSpace = LogisticSearchSpace(),
                  random_state: int = 42) -> tuple[Pipeline, pd.DataFrame]:
    """Pick the regularisation strength C with the lowest validation log loss."""
    rows, models = [], {}
    for C in space.C:
        model = make_logistic(C, random_state).fit(X_train, y_train)
        p = model.predict_proba(X_val)[:, 1]
        rows.append({"C": C, "val_log_loss": log_loss(y_val, p), "val_roc_auc": roc_auc_score(y_val, p)})
        models[C] = model
    results = pd.DataFrame(rows).sort_values("val_log_loss").reset_index(drop=True)
    best_C = results.loc[0, "C"]
    log.info("Logistic regression: best C = %s", best_C)
    return models[best_C], results


# ---------------------------------------------------------------------------
# Random forest
# ---------------------------------------------------------------------------
def make_random_forest(random_state: int = 42) -> Pipeline:
    """Random forest with ordinal-encoded categories and sentinel imputation.

    Hyperparameters are fixed (not tuned): the forest is a comparison point
    for LightGBM, not a candidate for the final system.
    """
    preprocess = ColumnTransformer([
        ("numeric", SimpleImputer(strategy="constant", fill_value=-1.0), NUMERIC_FEATURES),
        ("categorical", OrdinalEncoder(
            categories=[CATEGORY_LEVELS[c] for c in CATEGORICAL_FEATURES],
            handle_unknown="use_encoded_value", unknown_value=-1, encoded_missing_value=-1,
        ), CATEGORICAL_FEATURES),
    ])
    forest = RandomForestClassifier(
        n_estimators=300, min_samples_leaf=50, max_features="sqrt",
        n_jobs=-1, random_state=random_state,
    )
    return Pipeline([("preprocess", preprocess), ("model", forest)])


# ---------------------------------------------------------------------------
# LightGBM
# ---------------------------------------------------------------------------
def fit_lightgbm(X_train, y_train, X_val, y_val, params: dict,
                 space: LightGBMSearchSpace = LightGBMSearchSpace(),
                 random_state: int = 42) -> lgb.LGBMClassifier:
    """Fit LightGBM with early stopping on the validation log loss."""
    model = lgb.LGBMClassifier(
        objective="binary",
        learning_rate=space.learning_rate,
        n_estimators=space.max_rounds,
        subsample_freq=1,  # bagging every iteration (used with subsample < 1)
        random_state=random_state,
        verbose=-1,
        **params,
    )
    with warnings.catch_warnings():
        # LightGBM >= 4.7 prefers eval_X/eval_y; eval_set keeps older 4.x versions working.
        warnings.filterwarnings("ignore", message=".*eval_set.*deprecated", category=Warning)
        model.fit(
            X_train, y_train,
            eval_set=[(X_val, y_val)],
            eval_metric="binary_logloss",
            callbacks=[lgb.early_stopping(space.early_stopping_rounds, verbose=False)],
        )
    return model


def _sample_configs(space: LightGBMSearchSpace, seed: int) -> list[dict]:
    """Draw ``n_trials`` distinct configurations from the search grid."""
    grid = list(itertools.product(space.num_leaves, space.min_child_samples,
                                  space.feature_fraction, space.bagging_fraction, space.lambda_l2))
    rng = np.random.default_rng(seed)
    chosen = rng.choice(len(grid), size=min(space.n_trials, len(grid)), replace=False)
    keys = ("num_leaves", "min_child_samples", "colsample_bytree", "subsample", "reg_lambda")
    return [dict(zip(keys, grid[i])) for i in chosen]


def tune_lightgbm(X_train, y_train, X_val, y_val,
                  space: LightGBMSearchSpace = LightGBMSearchSpace(),
                  random_state: int = 42) -> tuple[lgb.LGBMClassifier, dict, pd.DataFrame]:
    """Random search; the configuration with the lowest validation log loss wins."""
    rows, best = [], (np.inf, None, None)
    for trial, params in enumerate(_sample_configs(space, random_state), start=1):
        model = fit_lightgbm(X_train, y_train, X_val, y_val, params, space, random_state)
        p = model.predict_proba(X_val)[:, 1]
        loss = log_loss(y_val, p)
        rows.append({**params, "best_iteration": model.best_iteration_,
                     "val_log_loss": loss, "val_roc_auc": roc_auc_score(y_val, p)})
        log.info("LightGBM trial %2d/%d: log loss %.4f", trial, space.n_trials, loss)
        if loss < best[0]:
            best = (loss, model, params)
    results = pd.DataFrame(rows).sort_values("val_log_loss").reset_index(drop=True)
    return best[1], best[2], results


# ---------------------------------------------------------------------------
# Calibration
# ---------------------------------------------------------------------------
@dataclass
class CalibratedModel:
    """A fitted model followed by a probability calibrator.

    The calibrator is fitted on validation predictions, never on test data.
    ``method`` is "isotonic" (non-parametric, monotone) or "sigmoid" (Platt
    scaling on the log-odds).
    """

    model: object
    method: str = "isotonic"

    def fit(self, X_val: pd.DataFrame, y_val: pd.Series) -> "CalibratedModel":
        raw = self.model.predict_proba(X_val)[:, 1]
        if self.method == "isotonic":
            self.calibrator_ = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
            self.calibrator_.fit(raw, y_val)
        elif self.method == "sigmoid":
            self.calibrator_ = LogisticRegression().fit(_logit(raw)[:, None], y_val)
        else:
            raise ValueError(f"Unknown calibration method {self.method!r}")
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        raw = self.model.predict_proba(X)[:, 1]
        if self.method == "isotonic":
            p = self.calibrator_.predict(raw)
        else:
            p = self.calibrator_.predict_proba(_logit(raw)[:, None])[:, 1]
        return np.column_stack([1 - p, p])


def _logit(p: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    p = np.clip(p, eps, 1 - eps)
    return np.log(p / (1 - p))
