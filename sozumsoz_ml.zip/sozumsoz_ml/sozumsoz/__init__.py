"""SözümSöz: data preparation and model exploration on the LSApp dataset."""
