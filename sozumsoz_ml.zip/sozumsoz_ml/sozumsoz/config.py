"""Central configuration for the SözümSöz modelling pipeline.

Every threshold that shapes the data or the models lives here, so that a
reader can see all analysis choices in one place and a sensitivity analysis
can change one value without touching the code.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
FIGURE_DIR = OUTPUT_DIR / "figures"
TABLE_DIR = OUTPUT_DIR / "tables"
CACHE_DIR = OUTPUT_DIR / "cache"

RAW_DATA_PATH = DATA_DIR / "lsapp.tsv.gz"
RAW_DATA_URL = "https://raw.githubusercontent.com/aliannejadi/LSApp/main/lsapp.tsv.gz"

# Duration options (seconds) of the in-app promise menu, used only by the
# "menu" promise rule in the sensitivity analysis.
PROMISE_MENU_S: tuple[int, ...] = (60, 120, 300, 600, 900, 1800, 3600)


@dataclass(frozen=True)
class PipelineConfig:
    """All data-preparation and modelling choices for one pipeline run.

    The defaults are the main-analysis settings reported in the write-up.
    Use ``cfg.with_(name=value)`` to create a variant for sensitivity runs.
    """

    # --- Visit construction (Section 3, Data Cleaning) ---------------------
    # Fragments of the same app separated by at most this many seconds are
    # merged into one continuous visit (LSApp logs an activity change inside
    # an app as a Closed/Opened pair within the same second).
    merge_gap_s: float = 1.0
    # Visits shorter than this are logging artefacts (open and close in the
    # same second) and are removed.
    min_visit_s: float = 1.0
    # Visits longer than this are treated as logging errors (e.g. a missing
    # Closed event while the screen was off) and are removed.
    max_visit_s: float = 3 * 3600
    # Inactivity gap that starts a new phone session. LSApp's own session_id
    # follows the same 5-minute rule (verified in EDA), and the rule can be
    # reproduced on a device.
    session_gap_s: float = 300.0

    # --- Promise simulation (Section 5, Feature Engineering) ---------------
    # "median" (main), "p75", "recent10" or "menu"; see promises.py.
    promise_rule: str = "median"
    # Minimum number of earlier visits of the same user in the same app
    # needed before a personal promise can be simulated.
    min_history: int = 5
    # If True, visits with less personal history receive a population-level
    # promise (cold-start analysis only; not used in the main model).
    cold_start: bool = False

    # --- Splits (Model Training) --------------------------------------------
    test_fraction: float = 0.20        # last 20% of labelled visits in time
    validation_fraction: float = 0.15  # last 15% of the training period
    n_person_folds: int = 5            # person-level cross-validation

    # --- Reproducibility -----------------------------------------------------
    random_state: int = 42

    def with_(self, **changes) -> "PipelineConfig":
        """Return a copy of the configuration with some fields changed."""
        return replace(self, **changes)


@dataclass(frozen=True)
class LightGBMSearchSpace:
    """Random-search space for LightGBM (Model Training)."""

    num_leaves: tuple[int, ...] = (15, 31, 63, 127)
    min_child_samples: tuple[int, ...] = (20, 50, 100, 200, 400)
    feature_fraction: tuple[float, ...] = (0.6, 0.8, 1.0)
    bagging_fraction: tuple[float, ...] = (0.7, 0.85, 1.0)
    lambda_l2: tuple[float, ...] = (0.0, 1.0, 10.0)
    n_trials: int = 24
    learning_rate: float = 0.05
    max_rounds: int = 3000
    early_stopping_rounds: int = 100


@dataclass(frozen=True)
class LogisticSearchSpace:
    """Regularisation strengths tried for logistic regression."""

    C: tuple[float, ...] = field(default=(0.01, 0.1, 1.0, 10.0))


DEFAULT_CONFIG = PipelineConfig()
