"""Experiments reported in the write-up.

prepare_table        cleaned events -> visit table with promises and features
exploratory_analysis EDA statistics and figures
main_experiment      model comparison on the chronological split
person_level_cv      generalisation to new users
sensitivity_analysis alternative promise rules and cleaning thresholds
cold_start_analysis  performance by amount of personal history
"""

from __future__ import annotations

import logging
from dataclasses import asdict
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from . import plots
from .apps import (BROWSER, CALLS, EMAIL, GAMES, MESSAGING, NAVIGATION, OTHER, PHOTOS,
                   SHOPPING, SOCIAL, SYSTEM, TOOLS, VIDEO)
from .config import FIGURE_DIR, LightGBMSearchSpace, PipelineConfig
from .data import build_visits
from .evaluation import (classification_metrics, cluster_bootstrap_ci, confusion_table,
                         overrun_summary)
from .features import FEATURES, add_features, to_model_frame
from .models import (CalibratedModel, HistoryBaseline, MajorityBaseline, fit_lightgbm,
                     make_logistic, make_random_forest, tune_lightgbm, tune_logistic)
from .promises import add_promises
from .splits import chronological_split, hold_out_users, person_folds

log = logging.getLogger(__name__)

# Categories used to test the concept note's "task app -> feed app" pattern.
TASK_CATEGORIES = {BROWSER, EMAIL, TOOLS, SYSTEM, NAVIGATION, CALLS, PHOTOS, SHOPPING}
FEED_CATEGORIES = {SOCIAL, VIDEO}
HEATMAP_CATEGORIES = [SOCIAL, MESSAGING, VIDEO, GAMES, BROWSER, EMAIL, CALLS, SYSTEM, TOOLS]


# ---------------------------------------------------------------------------
# Data preparation
# ---------------------------------------------------------------------------
def prepare_table(clean_events: pd.DataFrame, cfg: PipelineConfig) -> tuple[pd.DataFrame, dict]:
    """Visits -> promises -> features for one configuration."""
    visits, report = build_visits(clean_events, cfg)
    table = add_features(add_promises(visits, cfg))
    labelled = table.loc[table["labelled"]]
    report.update({
        "labelled_visits": int(len(labelled)),
        "labelled_users": int(labelled["user_id"].nunique()),
        "keep_rate": float(labelled["kept"].mean()),
        "config": asdict(cfg),
    })
    return table, report


def split_labelled(table: pd.DataFrame, cfg: PipelineConfig):
    """Return labelled rows, (X, y) and the chronological split."""
    labelled = table.loc[table["labelled"]].reset_index(drop=True)
    X, y = to_model_frame(table)
    X, y = X.reset_index(drop=True), y.reset_index(drop=True)
    split = chronological_split(labelled["start"], cfg.test_fraction, cfg.validation_fraction)
    return labelled, X, y, split


# ---------------------------------------------------------------------------
# Exploratory data analysis
# ---------------------------------------------------------------------------
def _transition_matrix(table: pd.DataFrame) -> pd.DataFrame:
    """Row-normalised P(next category | current category) within sessions."""
    category = table["category"].where(table["category"].isin(HEATMAP_CATEGORIES), OTHER)
    nxt = category.groupby(table["session"], sort=False).shift(-1)
    pairs = pd.DataFrame({"current": category, "next": nxt}).dropna()
    order = HEATMAP_CATEGORIES + [OTHER]
    counts = pd.crosstab(pairs["current"], pairs["next"]).reindex(index=order, columns=order, fill_value=0)
    return counts.div(counts.sum(axis=1), axis=0)


def _drift_statistics(table: pd.DataFrame) -> dict:
    """Do sessions that start in a task-oriented app drift into a feed app?"""
    sessions = table.groupby("session", sort=False).agg(
        first=("category", "first"), n=("category", "size"),
        later=("category", lambda s: bool(set(s.iloc[1:]) & FEED_CATEGORIES)),
    )
    multi = sessions[sessions["n"] >= 2]
    starts_task = multi["first"].isin(TASK_CATEGORIES)
    starts_other_non_feed = ~starts_task & ~multi["first"].isin(FEED_CATEGORIES)
    return {
        "multi_visit_sessions": int(len(multi)),
        "share_starting_in_task_app": float(starts_task.mean()),
        "feed_later_if_task_start": float(multi.loc[starts_task, "later"].mean()),
        "feed_later_if_other_non_feed_start": float(multi.loc[starts_other_non_feed, "later"].mean()),
    }


def exploratory_analysis(clean_events: pd.DataFrame, table: pd.DataFrame,
                         figure_dir: Path = FIGURE_DIR) -> dict:
    """Compute EDA statistics and draw the EDA figures."""
    target = table.loc[table["is_target_app"]]
    labelled = table.loc[table["labelled"]]
    per_user = table.groupby("user_id").size().sort_values(ascending=False)
    days = table.groupby("user_id")["start"].agg(lambda s: s.dt.normalize().nunique())
    hourly = table["start"].dt.hour.value_counts(normalize=True).sort_index()

    def describe(d: pd.Series) -> dict:
        return {"n": int(len(d)), "median_s": float(d.median()), "mean_s": float(d.mean()),
                "p90_s": float(d.quantile(0.9)), "share_over_10min": float((d > 600).mean())}

    stats = {
        "duration_all": describe(table["duration_s"]),
        "duration_target": describe(target["duration_s"]),
        "duration_by_target_category": {c: describe(g["duration_s"]) for c, g in target.groupby("category")},
        "observation_days": {"median": float(days.median()), "mean": float(days.mean())},
        "top10_users_share_of_visits": float(per_user.head(10).sum() / per_user.sum()),
        "hour_min": {"hour": int(hourly.idxmin()), "share": float(hourly.min())},
        "hour_max": {"hour": int(hourly.idxmax()), "share": float(hourly.max())},
        "drift": _drift_statistics(table),
        "keep_rate_by_category": labelled.groupby("category")["kept"].mean().to_dict(),
        "keep_rate_by_hour_range": [float(labelled.groupby(labelled["start"].dt.hour)["kept"].mean().min()),
                                    float(labelled.groupby(labelled["start"].dt.hour)["kept"].mean().max())],
    }

    plots.data_coverage(clean_events, table, figure_dir / "fig01_data_coverage.png")
    plots.duration_distribution(table, figure_dir / "fig02_durations.png")
    plots.activity_by_time(table, figure_dir / "fig03_time_of_use.png")
    plots.survival_by_category(target, figure_dir / "fig04_survival.png")
    plots.category_transitions(_transition_matrix(table), figure_dir / "fig05_transitions.png")
    plots.keep_rate_by_context(labelled, figure_dir / "fig06_keep_rate_context.png")
    return stats


# ---------------------------------------------------------------------------
# Main experiment: chronological split
# ---------------------------------------------------------------------------
def _lightgbm_importance(model, X: pd.DataFrame, n: int, seed: int) -> pd.Series:
    """Mean |SHAP| per feature, computed with LightGBM's built-in TreeSHAP."""
    sample = X.sample(n=min(n, len(X)), random_state=seed)
    contributions = model.predict(sample, pred_contrib=True)[:, :-1]  # last column = bias
    return pd.Series(np.abs(contributions).mean(axis=0), index=FEATURES).sort_values(ascending=False)


def _logistic_coefficients(model) -> pd.Series:
    """Coefficients of the logistic model on its (scaled / one-hot) inputs."""
    names = model.named_steps["preprocess"].get_feature_names_out()
    coef = model.named_steps["model"].coef_.ravel()
    return pd.Series(coef, index=names).sort_values(key=np.abs, ascending=False)


def _risk_concentration(test: pd.DataFrame, p: np.ndarray, share: float = 0.2) -> dict:
    """How many broken promises fall into the riskiest ``share`` of visits?"""
    riskiest = p <= np.quantile(p, share)
    broken = test["kept"].to_numpy() == 0
    overrun = test["overrun_s"].to_numpy()
    return {
        "share_of_visits": share,
        "keep_rate_in_riskiest": float(1 - broken[riskiest].mean()),
        "share_of_broken_promises": float(broken[riskiest].sum() / broken.sum()),
        "share_of_overrun_seconds": float(overrun[riskiest].sum() / overrun.sum()),
    }


def main_experiment(table: pd.DataFrame, cfg: PipelineConfig,
                    figure_dir: Path = FIGURE_DIR) -> dict:
    """Train all models on the chronological split and evaluate them on test."""
    labelled, X, y, split = split_labelled(table, cfg)
    X_tr, y_tr = X.iloc[split.train], y.iloc[split.train]
    X_val, y_val = X.iloc[split.validation], y.iloc[split.validation]
    X_te, y_te = X.iloc[split.test], y.iloc[split.test]
    test = labelled.iloc[split.test]

    log.info("Fitting baselines, logistic regression and random forest")
    majority = MajorityBaseline().fit(X_tr, y_tr)
    history = HistoryBaseline().fit(X_tr, y_tr)
    logistic, logistic_search = tune_logistic(X_tr, y_tr, X_val, y_val, random_state=cfg.random_state)
    forest = make_random_forest(cfg.random_state).fit(X_tr, y_tr)

    log.info("Tuning LightGBM")
    lightgbm, best_params, lightgbm_search = tune_lightgbm(X_tr, y_tr, X_val, y_val,
                                                           random_state=cfg.random_state)
    lightgbm_isotonic = CalibratedModel(lightgbm, "isotonic").fit(X_val, y_val)
    lightgbm_sigmoid = CalibratedModel(lightgbm, "sigmoid").fit(X_val, y_val)

    models = {
        "Majority baseline": majority,
        "History baseline": history,
        "Logistic regression": logistic,
        "Random forest": forest,
        "LightGBM (raw)": lightgbm,
        "LightGBM + isotonic": lightgbm_isotonic,
        "LightGBM + Platt": lightgbm_sigmoid,
    }
    predictions = {name: m.predict_proba(X_te)[:, 1] for name, m in models.items()}
    validation_predictions = {name: m.predict_proba(X_val)[:, 1] for name, m in models.items()}

    rows = []
    for name, p in predictions.items():
        metrics = classification_metrics(y_te, p)
        if name != "Majority baseline":
            metrics["roc_auc_ci"] = cluster_bootstrap_ci(y_te, p, test["user_id"], seed=cfg.random_state)
        metrics["val_roc_auc"] = classification_metrics(y_val, validation_predictions[name])["roc_auc"]
        rows.append({"model": name, **metrics})
    test_metrics = pd.DataFrame(rows).set_index("model")

    # Known vs new users inside the chronological test period
    seen = test["user_id"].isin(set(labelled.iloc[split.train]["user_id"])).to_numpy()
    y_te_array = y_te.to_numpy()
    by_user_type = {
        group: {name: classification_metrics(y_te_array[mask], predictions[name][mask])
                for name in ["History baseline", "Logistic regression", "LightGBM + isotonic"]}
        for group, mask in [("seen_in_training", seen), ("new_in_test", ~seen)]
    }
    best_name = "LightGBM + isotonic"
    confusion = confusion_table(y_te, predictions[best_name])
    importance = _lightgbm_importance(lightgbm, X_te, n=5000, seed=cfg.random_state)

    plots.roc_and_pr(y_te, {k: predictions[k] for k in
                            ["History baseline", "Logistic regression", "Random forest", "LightGBM + isotonic"]},
                     figure_dir / "fig07_roc_pr.png")
    plots.reliability(y_te, {k: predictions[k] for k in
                             ["Logistic regression", "LightGBM (raw)", "LightGBM + isotonic"]},
                      figure_dir / "fig08_calibration.png")
    plots.confusion(confusion, figure_dir / "fig09_confusion.png")
    plots.feature_importance(importance, figure_dir / "fig10_shap.png")

    return {
        "split": {
            "validation_start": str(split.validation_start), "test_start": str(split.test_start),
            "n_train": int(len(split.train)), "n_validation": int(len(split.validation)),
            "n_test": int(len(split.test)),
            "users_train": int(labelled.iloc[split.train]["user_id"].nunique()),
            "users_validation": int(labelled.iloc[split.validation]["user_id"].nunique()),
            "users_test": int(test["user_id"].nunique()),
            "test_users_new": int(test.loc[~seen, "user_id"].nunique()),
            "test_rows_new_users": int((~seen).sum()),
            "keep_rate_train": float(y_tr.mean()), "keep_rate_test": float(y_te.mean()),
        },
        "test_metrics": test_metrics,
        "by_user_type": by_user_type,
        "confusion": confusion,
        "importance": importance,
        "logistic_search": logistic_search,
        "logistic_top_coefficients": _logistic_coefficients(logistic).head(12),
        "lightgbm_search": lightgbm_search,
        "lightgbm_best_params": {**best_params, "n_estimators": int(lightgbm.best_iteration_)},
        "best_C": float(logistic_search.loc[0, "C"]),
        "overrun_test": overrun_summary(test),
        "risk_concentration": _risk_concentration(test, predictions[best_name]),
    }


# ---------------------------------------------------------------------------
# Robustness
# ---------------------------------------------------------------------------
def _fit_calibrated_lightgbm(X_fit, y_fit, X_hold, y_hold, params: dict, seed: int):
    model = fit_lightgbm(X_fit, y_fit, X_hold, y_hold, params, LightGBMSearchSpace(), seed)
    return CalibratedModel(model, "isotonic").fit(X_hold, y_hold)


def person_level_cv(table: pd.DataFrame, cfg: PipelineConfig, best_params: dict,
                    best_C: float) -> pd.DataFrame:
    """Person-level CV: test users are never seen during training.

    Inside each training fold, 15% of the users are held out for early
    stopping and calibration, so that they are also "new" users.
    """
    labelled = table.loc[table["labelled"]].reset_index(drop=True)
    X, y = to_model_frame(table)
    X, y = X.reset_index(drop=True), y.reset_index(drop=True)
    groups = labelled["user_id"]
    params = {k: v for k, v in best_params.items() if k != "n_estimators"}

    rows = []
    for fold, (train_pos, test_pos) in enumerate(person_folds(groups, cfg.n_person_folds), start=1):
        fit_pos, hold_pos = hold_out_users(groups, train_pos, 0.15, cfg.random_state + fold)
        lgbm = _fit_calibrated_lightgbm(X.iloc[fit_pos], y.iloc[fit_pos],
                                        X.iloc[hold_pos], y.iloc[hold_pos], params, cfg.random_state)
        logistic = make_logistic(best_C, cfg.random_state).fit(X.iloc[fit_pos], y.iloc[fit_pos])
        history = HistoryBaseline().fit(X.iloc[fit_pos], y.iloc[fit_pos])
        for name, model in [("History baseline", history), ("Logistic regression", logistic),
                            ("LightGBM + isotonic", lgbm)]:
            metrics = classification_metrics(y.iloc[test_pos], model.predict_proba(X.iloc[test_pos])[:, 1])
            rows.append({"fold": fold, "model": name, "test_users": int(groups.iloc[test_pos].nunique()),
                         **metrics})
        log.info("Person-level CV fold %d done", fold)
    return pd.DataFrame(rows)


def sensitivity_analysis(clean_events: pd.DataFrame, cfg: PipelineConfig,
                         best_params: dict) -> pd.DataFrame:
    """Re-run data preparation and LightGBM under alternative choices."""
    params = {k: v for k, v in best_params.items() if k != "n_estimators"}
    variants = {
        "Main (median, gap 1 s, min 1 s)": cfg,
        "Promise = 75th percentile": cfg.with_(promise_rule="p75"),
        "Promise = median of last 10": cfg.with_(promise_rule="recent10"),
        "Promise = median rounded up to menu": cfg.with_(promise_rule="menu"),
        "Merge gap 0 s": cfg.with_(merge_gap_s=0.0),
        "Merge gap 5 s": cfg.with_(merge_gap_s=5.0),
        "Keep zero-second visits": cfg.with_(min_visit_s=0.0),
    }
    rows = []
    for name, variant in variants.items():
        table, report = prepare_table(clean_events, variant)
        labelled, X, y, split = split_labelled(table, variant)
        model = _fit_calibrated_lightgbm(X.iloc[split.train], y.iloc[split.train],
                                         X.iloc[split.validation], y.iloc[split.validation],
                                         params, variant.random_state)
        metrics = classification_metrics(y.iloc[split.test], model.predict_proba(X.iloc[split.test])[:, 1])
        rows.append({"variant": name, "labelled_visits": report["labelled_visits"],
                     **{f"test_{k}": v for k, v in metrics.items() if k in ("roc_auc", "pr_auc", "brier", "ece")},
                     **overrun_summary(labelled.iloc[split.test])})
        log.info("Sensitivity variant done: %s", name)
    return pd.DataFrame(rows).set_index("variant")


def cold_start_analysis(clean_events: pd.DataFrame, cfg: PipelineConfig, best_params: dict,
                        figure_dir: Path = FIGURE_DIR) -> pd.DataFrame:
    """Performance by personal history length, using a population fallback promise.

    Visits with fewer than ``min_history`` earlier visits get the app-level
    population median as their promise. One LightGBM model is trained on
    all labelled visits, and test performance is reported per history bucket.
    """
    variant = cfg.with_(cold_start=True)
    table, _ = prepare_table(clean_events, variant)
    labelled, X, y, split = split_labelled(table, variant)
    params = {k: v for k, v in best_params.items() if k != "n_estimators"}
    model = _fit_calibrated_lightgbm(X.iloc[split.train], y.iloc[split.train],
                                     X.iloc[split.validation], y.iloc[split.validation],
                                     params, variant.random_state)
    p = model.predict_proba(X.iloc[split.test])[:, 1]
    test = labelled.iloc[split.test].assign(p=p)

    buckets = pd.cut(test["n_prev_app"], [-1, 0, 4, 19, 99, np.inf],
                     labels=["0", "1–4", "5–19", "20–99", "100+"])
    rows = {}
    for bucket, group in test.groupby(buckets, observed=True):
        low, high = cluster_bootstrap_ci(group["kept"], group["p"], group["user_id"], seed=cfg.random_state)
        rows[bucket] = {"n": int(len(group)), "users": int(group["user_id"].nunique()),
                        "keep_rate": float(group["kept"].mean()),
                        "roc_auc": float(roc_auc_score(group["kept"], group["p"])),
                        "roc_auc_low": low, "roc_auc_high": high,
                        "promise_source": group["promise_source"].mode().iat[0]}
    result = pd.DataFrame(rows).T
    result[["n", "users"]] = result[["n", "users"]].astype(int)
    result[["keep_rate", "roc_auc", "roc_auc_low", "roc_auc_high"]] = \
        result[["keep_rate", "roc_auc", "roc_auc_low", "roc_auc_high"]].astype(float)
    plots.history_buckets(result, figure_dir / "fig11_history_buckets.png")
    return result
